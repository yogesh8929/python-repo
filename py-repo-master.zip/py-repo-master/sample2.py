# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:47:14 2020

@author: gaurav.pr
"""

import sample1

sample1.mostimportantfunction()