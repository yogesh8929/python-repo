# -*- coding: utf-8 -*-
"""
Created on Fri Oct  9 12:42:45 2020

@author: gaurav.pr
"""

import os

def mostimportantfunction():
    print("I am a coder")

print(__name__)

if(__name__=="__main__"):

    print("-----------------------------------------------------")
    print(os.listdir("/"))
    print("-----------------------------------------------------")
    print("I am the king of India")
    
    print("-----------------------------------------------------")

#mostimportantfunction()